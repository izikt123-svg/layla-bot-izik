/* ============================================================
   KZ HERO VIDEO — 360° / 4K cinematic hero banner
   Replaces kz-hero-slider.js. Inserts an immersive video
   banner above the topbar (same mounting point the slider used).

   Configure your video by setting window.KZ_HERO_VIDEO before
   this script loads, or edit DEFAULT_CONFIG below:

   <script>
     window.KZ_HERO_VIDEO = {
       provider: 'youtube',     // 'youtube' | 'mp4'
       id: 'YOUTUBE_VIDEO_ID',  // 360 video id (e.g. Jerusalem 360 4K)
       mp4Url: '',              // alternative: direct .mp4 url
       poster: '/path/to/hero-poster.jpg',
       muted: true,
       loop: true,
       title: 'הר הבית · ירושלים 360°'
     };
   </script>
   ============================================================ */
(function(){
  'use strict';

  // Default: a curated 360° Jerusalem clip. Swap freely.
  // To find your own: youtube.com → search "Jerusalem 360 4K"
  // or "Western Wall 360" — copy the id after watch?v=
  const DEFAULT_CONFIG = {
    provider: 'youtube',
    id: 'aqz-KE-bpKQ',           // PLACEHOLDER — replace with your 360 video id
    mp4Url: '',
    poster: '',
    muted: true,
    loop: true,
    title: 'מרכז התפילה · ירושלים 360°'
  };

  const cfg = Object.assign({}, DEFAULT_CONFIG, window.KZ_HERO_VIDEO || {});

  function buildBanner(){
    if (document.querySelector('.kz-hero-video')) return;

    const wrap = document.createElement('div');
    wrap.className = 'kz-hero-video';
    wrap.setAttribute('aria-label', cfg.title);

    if (cfg.provider === 'youtube' && cfg.id){
      // YouTube has native 360° support. Drag to look around.
      const params = new URLSearchParams({
        autoplay: '1',
        mute: cfg.muted ? '1' : '0',
        loop: cfg.loop ? '1' : '0',
        playlist: cfg.id,         // required for loop on YouTube
        controls: '1',
        modestbranding: '1',
        rel: '0',
        playsinline: '1',
        iv_load_policy: '3'
      });
      wrap.innerHTML = `
        <div class="kz-hv-shell">
          <iframe
            class="kz-hv-frame"
            src="https://www.youtube-nocookie.com/embed/${encodeURIComponent(cfg.id)}?${params}"
            title="${escapeHtml(cfg.title)}"
            loading="lazy"
            allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
            allowfullscreen
            referrerpolicy="strict-origin-when-cross-origin"></iframe>
          <div class="kz-hv-vignette" aria-hidden="true"></div>
          <div class="kz-hv-caption">
            <span class="kz-hv-pill">🌍 360°</span>
            <span class="kz-hv-title">${escapeHtml(cfg.title)}</span>
            <span class="kz-hv-hint">גרור כדי להסתכל סביב</span>
          </div>
        </div>`;
    } else if (cfg.mp4Url){
      // Self-hosted MP4 fallback (no 360 panning, but cinematic).
      wrap.innerHTML = `
        <div class="kz-hv-shell">
          <video
            class="kz-hv-video"
            ${cfg.muted ? 'muted' : ''}
            ${cfg.loop ? 'loop' : ''}
            autoplay playsinline preload="metadata"
            ${cfg.poster ? `poster="${escapeAttr(cfg.poster)}"` : ''}>
            <source src="${escapeAttr(cfg.mp4Url)}" type="video/mp4">
          </video>
          <div class="kz-hv-vignette" aria-hidden="true"></div>
          <div class="kz-hv-caption">
            <span class="kz-hv-title">${escapeHtml(cfg.title)}</span>
          </div>
        </div>`;
    } else {
      // Nothing configured — render a quiet gradient placeholder so the page still looks intentional.
      wrap.classList.add('kz-hv-empty');
      wrap.innerHTML = `<div class="kz-hv-shell"><div class="kz-hv-caption">
        <span class="kz-hv-title">${escapeHtml(cfg.title)}</span>
      </div></div>`;
    }

    document.body.insertBefore(wrap, document.body.firstChild);
  }

  function escapeHtml(s){
    return String(s ?? '').replace(/[&<>"']/g, m => ({
      '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
    }[m]));
  }
  function escapeAttr(s){ return escapeHtml(s); }

  if (document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', buildBanner, { once: true });
  } else {
    buildBanner();
  }

  window.KZ_HERO_VIDEO_API = {
    rebuild(){
      const old = document.querySelector('.kz-hero-video');
      if (old) old.remove();
      buildBanner();
    }
  };
})();
