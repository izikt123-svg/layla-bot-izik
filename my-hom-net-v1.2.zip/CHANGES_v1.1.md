# 🔥 שינויים בגרסה v1.1 — מרכז התפילה / my-hom.net

## ✅ מה תוקן ומה נוסף

### 1. 🎥 Hero חדש — סרטון 360° / 4K
- נמחק הסליידר הישן (`kz-hero-slider.js`) שגרם להתנגשויות עם האנימציות.
- נוצרו: `kz-hero-video.js` + `kz-hero-video.css` — באנר קולנועי בראש הדף.
- ברירת מחדל: עוטף סרטון YouTube עם תמיכה מלאה ב-360° (גרירה כדי להסתכל סביב).
- **איך מחליפים את הסרטון:** עורכים את `kz-hero-video.js` שורה 32 — שדה `id` — ומחליפים ב-Video ID של YouTube. למצוא Video ID:
  - חיפוש ב-YouTube: `Jerusalem 360 4K`, `Western Wall 360`, `Kotel VR`.
  - הקישור נראה `https://youtube.com/watch?v=ABCD1234` → ה-id הוא `ABCD1234`.
- חלופה: סרטון MP4 משלך — `provider: 'mp4'` + `mpUrl: 'https://...'`.

### 2. 💾 Service Worker — תוקן באג ה"אתר הישן עולה"
- `sw.js` שורה 8: VERSION עלתה ל-`v1.1.0-2026-05-06`.
- מעכשיו: **Network-first** ל-HTML (תמיד גרסה טרייה), Stale-while-revalidate ל-CSS/JS.
- כשעולה גרסה חדשה — מופיעה למשתמש בועה זהובה למטה: "✦ גרסה חדשה — לחץ לרענון".
- **חוקי זהב:** כל פעם שאתה מעלה שינוי גדול לאתר, פתח את `sw.js`, שנה את התאריך ב-VERSION (למשל `v1.1.1-2026-05-15`), ושמור. זה בלבד יבטיח שכולם יקבלו את החדש.

### 3. 🤖 מירב — AI אמיתי (Gemini)
- נוצרה Netlify Function: `netlify/functions/ai.js` — מתווכת בטוחה לבין הדפדפן ל-Gemini.
- **API key נשאר בשרת בלבד** — לא נחשף ב-HTML.
- `kz-ai-chat.js` עודכן: כל שאלה הולכת ל-`/api/ai`. אם השרת לא זמין → fallback אוטומטי לתשובות הסטטיות הישנות (אז אף פעם לא נכשל).
- **התקנה ב-Netlify:**
  1. Netlify Dashboard → Site settings → Environment variables.
  2. הוסף: `GEMINI_API_KEY` = המפתח שלך מ-https://aistudio.google.com/apikey
  3. Deploy.
- מירב מקבלת **System Prompt** מותאם לאתר: יודעת על מפת היהדות, חדר משפחה, תפילות, יארצייט, וכו'.
- שומרת היסטוריית שיחה (12 הודעות אחרונות) → זוכרת הקשר.

### 4. 🌍 100+ מקומות חדשים במאגר
| קטגוריה | קודם | עכשיו | תוספת |
|---------|------|-------|-------|
| 🕎 בתי חב"ד  | 232 | **260** | +28 (סינגפור, דובאי, איסטנבול, מאוריציוס, סיישל, באלי, טוקיו, איסלנד, ועוד) |
| 🍽 כשרות     | 15  | **59**  | +44 מסעדות (NYC, פריז, לונדון, רומא, מיאמי, מלבורן, אנטוורפן, ועוד) |
| 🏛 JCC       | 9   | **14**  | +5 (ברלין, פריז, בואנוס איירס, ועוד) |
| ⭐ אתרים קדושים | 2   | **5**   | +3 (הר הבית, תל שילה, קבר רחל) |

---

## ⚠️ פעולות ידניות שאתה צריך לעשות

### חובה (לפני העלאה):
1. **API Key ל-Gemini** (חינם):  
   → https://aistudio.google.com/apikey → Create API key → העתק.  
   ב-Netlify: Site settings → Environment → הוסף `GEMINI_API_KEY`.

2. **Video ID ל-Hero**:  
   ערוך `kz-hero-video.js` שורה 32 → החלף `'aqz-KE-bpKQ'` ב-id אמיתי של סרטון 360 שאתה רוצה.

### מומלץ:
3. **Google Search Console** — `index.html` שורה 27 (`REPLACE_WITH_YOUR_GOOGLE_VERIFICATION_CODE`).
4. **Google Analytics** — `index.html` שורות 30+35 (`G-REPLACE_ME` → המזהה שלך).
5. **PayPal/Bit/PayBox** — `kz-supreme.js` שורה 270 (DONATE_CONFIG).
6. **Supabase** — `kz-auth-supabase.js` (כשתפתח חשבון בסופאבייס).

---

## 📁 קבצים שהשתנו / נוספו

```
+ kz-hero-video.js        חדש
+ kz-hero-video.css       חדש
+ netlify/functions/ai.js חדש (Gemini proxy)
+ netlify.toml            חדש (redirects + headers)
+ CHANGES_v1.1.md         זה הקובץ
~ kz-ai-chat.js           חיווט ל-Gemini + fallback
~ kz-hero-slider.js       רוקנה לקובץ no-op (תאימות אחורה)
~ kz-hero-slider.css      רוקנה
~ sw.js                   VERSION + network-first ל-HTML
~ script.js               בועת "גרסה חדשה" + auto-update
~ index.html              הוספת קישורים לקבצים חדשים
~ data/jewish-places.js   +100 מקומות
```

---

## 🚀 מה הלאה (הצעות לסבב הבא)
1. PWA Push Notifications אמיתיים (VAPID).
2. צ'אט קולי למירב (Web Speech API).
3. Live counter של מתפללים (Supabase Realtime).
4. Page-by-page lazy loading של ה-CSS (פיצול 116KB).
5. תרגום אוטומטי של AI לפי שפת המשתמש.
