/* ============================================================
   KZ KOTEL CAM — embed a live feed from the Western Wall
   Renders into [data-kz-kotel] or appends a card after the hero
   dashboard if no mount is present. Uses a configurable provider
   so you can swap the source.

     window.KZ_KOTEL_CAM = {
       provider: 'youtube',     // 'youtube' | 'iframe'
       id: 'YOUTUBE_LIVE_ID',   // e.g. live stream from kotel.org
       url: 'https://…',        // raw iframe url for non-youtube
       title: 'הכותל המערבי · שידור חי'
     };
   ============================================================ */
(function(){
  'use strict';

  const DEFAULT = {
    provider: 'youtube',
    // Public official Kotel Heritage Foundation live stream id (verify before deploy).
    // Find current id at https://english.thekotel.org/cameras/ or YouTube live search.
    id: 'BBcjnIQrxFQ',
    url: '',
    title: 'הכותל המערבי · שידור חי'
  };

  const cfg = Object.assign({}, DEFAULT, window.KZ_KOTEL_CAM || {});

  function buildCard(){
    if (document.querySelector('.kz-kotel-card')) return;

    const card = document.createElement('section');
    card.className = 'kz-kotel-card card';
    card.setAttribute('aria-label', cfg.title);
    let inner = '';
    if (cfg.provider === 'youtube' && cfg.id){
      const params = new URLSearchParams({
        autoplay: '1', mute: '1', controls: '1', modestbranding: '1', rel: '0', playsinline: '1'
      });
      inner = `<iframe class="kz-kotel-frame"
        src="https://www.youtube-nocookie.com/embed/${encodeURIComponent(cfg.id)}?${params}"
        title="${escapeHtml(cfg.title)}"
        loading="lazy"
        allow="autoplay; encrypted-media; picture-in-picture"
        allowfullscreen></iframe>`;
    } else if (cfg.url){
      inner = `<iframe class="kz-kotel-frame" src="${escapeAttr(cfg.url)}" title="${escapeHtml(cfg.title)}" loading="lazy" allow="autoplay; encrypted-media" allowfullscreen></iframe>`;
    } else {
      inner = `<div class="kz-kotel-empty">לא הוגדר שידור חי</div>`;
    }
    card.innerHTML = `
      <div class="mini-title">
        <span class="mini-ornament">🕯</span>
        ${escapeHtml(cfg.title)}
        <span class="kz-kotel-live">LIVE</span>
      </div>
      <div class="kz-kotel-shell">${inner}</div>
      <div class="kz-kotel-foot">
        <a class="kz-kotel-share" href="https://wa.me/?text=${encodeURIComponent('הצטרפו לתפילה ליד הכותל · ' + (location.href || 'https://my-hom.net'))}" target="_blank" rel="noopener">שתף בוואטסאפ</a>
      </div>`;

    const mount = document.querySelector('[data-kz-kotel]');
    if (mount){ mount.appendChild(card); return; }

    // Auto-place: after the hero dashboard, before the next section.
    const hero = document.querySelector('.hero');
    if (hero && hero.parentNode){
      const dash = hero.querySelector('.hero-dash');
      if (dash){ dash.appendChild(card); return; }
      hero.parentNode.insertBefore(card, hero.nextSibling);
      return;
    }
    document.body.appendChild(card);
  }

  function escapeHtml(s){
    return String(s ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  }
  function escapeAttr(s){ return escapeHtml(s); }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', buildCard, { once: true });
  else buildCard();
})();
