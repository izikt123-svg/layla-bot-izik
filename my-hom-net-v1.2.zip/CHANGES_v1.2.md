# 🌍 גרסה v1.2 — מרכז התפילה / my-hom.net

## ✅ מה התווסף בסבב הזה

### 1. 🎙️ צ'אט קולי למירב
- כפתור מיקרופון בצ'אט: לחיצה → מקליטה דיבור (Web Speech API), שולחת אוטומטית.
- מירב יכולה גם **לדבר בקול** (TTS) — מופעל אופציונלית: `kzMiravSpeakToggle(true)`.
- תומך בעברית RTL ובכל שפה שהדפדפן מזהה.

### 2. 🔔 Push Notifications אמיתיים (VAPID)
- בועת opt-in מנומסת (לא בכניסה הראשונה — רק מהביקור השני, אחרי 45 שניות).
- 3 Netlify Functions חדשים:
  - `/api/push-subscribe` — שמירת הרשמה ב-Supabase.
  - `/api/push-unsubscribe`
  - `/api/push-send` — שליחת push לכל הקהל (מאובטח עם `x-push-secret`).
- ה-Service Worker מקבל push event ומציג notification עם clickthrough.
- מחיקה אוטומטית של הרשמות שפגו (404/410).

### 3. 📊 Live Counter — מתפללים עכשיו
- מודול `kz-live-counter.js` שמעדכן את "126 לבבות נושאים תפילה יחד" בזמן אמת.
- Heartbeat כל 30 שניות + פולינג כל 15 שניות.
- Function `/api/counter` עם fallback פסאודו-לייב חכם (תלוי שעה ביום) — אם Supabase לא מוגדר, ה-UI לעולם לא יראה 0.
- Animation count-up חלק.

### 4. 🌐 תרגום AI אוטומטי
- מזהה שפת דפדפן → מציע תרגום בלחיצה (לא אוטומטי, מכבד את העברית המקורית).
- שומר בחירת שפה ב-localStorage; פעם הבאה → תרגום מיידי.
- 10 שפות: en, fr, es, ru, de, it, pt, ar, tr, zh.
- Function `/api/translate` בטוץ' של 80 מחרוזות, cache בצד הלקוח, החלפת attributes ל-`dir="rtl"` בערבית.

### 5. 🔍 SEO — JSON-LD Structured Data
- הוספתי 3 בלוקי schema.org ל-`index.html`:
  - WebSite + SearchAction
  - Organization
  - FAQPage (תשובות לשאלות נפוצות → rich snippets ב-Google)

### 6. 📺 Live Kotel Webcam
- כרטיס "הכותל המערבי · שידור חי" עם badge "LIVE" פועם.
- ברירת מחדל: YouTube live id (תוודאו שהמזהה עדכני ב-https://english.thekotel.org/cameras/).
- כפתור שיתוף בוואטסאפ.

### 7. ⚡ Critical CSS Split
- `critical.css` חדש (~3KB) — נטען סינכרוני, מציג topbar+hero ב-100ms הראשונות.
- `styles.css` (116KB) נטען async דרך `rel="preload"` עם fallback.
- שיפור צפוי ב-LCP: 2-4 שניות → ~1 שנייה.

### 8. 🔄 Service Worker v1.2
- VERSION עלתה. כשתעלה את הזיפ — כל מי שביקר יראה את בועת "גרסה חדשה — לחץ לרענון".
- `critical.css` נוסף לרשימת cache.

---

## 🔧 הגדרות סביבה ב-Netlify (כדי שהכל יעבוד)

```
GEMINI_API_KEY         ← מ-https://aistudio.google.com/apikey
SUPABASE_URL           ← Supabase project settings
SUPABASE_SERVICE_KEY   ← Supabase → service_role key (לא anon!)
VAPID_PUBLIC           ← npx web-push generate-vapid-keys
VAPID_PRIVATE
VAPID_SUBJECT          ← mailto:you@my-hom.net
PUSH_SECRET            ← מחרוזת אקראית ארוכה (להגנה על /api/push-send)
```

ב-`index.html` להחליף:
```html
<script>window.KZ_VAPID_PUBLIC = 'REPLACE_WITH_VAPID_PUBLIC_KEY';</script>
```
ב-VAPID_PUBLIC האמיתי שיצרת.

---

## 🗄️ SQL חדש לטבלאות ב-Supabase

```sql
create table push_subscriptions (
  id uuid primary key default gen_random_uuid(),
  endpoint text unique not null,
  p256dh text not null,
  auth text not null,
  lang text default 'he',
  created_at timestamp with time zone default now()
);
alter table push_subscriptions enable row level security;

create table prayer_heartbeats (
  sid text primary key,
  at timestamp with time zone default now()
);
create index on prayer_heartbeats (at);
alter table prayer_heartbeats enable row level security;

-- Cron (Supabase → Database → Functions): מחק heartbeats מעל 5 דקות
-- (או הריצי את זה ידנית מדי פעם)
delete from prayer_heartbeats where at < now() - interval '5 minutes';
```

---

## 📁 קבצים חדשים בגרסה הזו

```
+ kz-push.js / .css                  - VAPID push opt-in
+ kz-live-counter.js                 - Live praying counter
+ kz-i18n-auto.js / .css             - AI translate offer
+ kz-kotel-cam.js / .css             - Live Kotel webcam card
+ critical.css                       - Above-the-fold CSS
+ netlify/functions/push-subscribe.js
+ netlify/functions/push-unsubscribe.js
+ netlify/functions/push-send.js
+ netlify/functions/counter.js
+ netlify/functions/translate.js
+ CHANGES_v1.2.md                    - This file
~ kz-ai-chat.js / .css               - Voice in/out (mic + TTS)
~ sw.js                              - VERSION + push handler
~ index.html                         - JSON-LD + script/css refs + critical CSS
~ netlify.toml                       - new redirects
```

---

## 🚀 הצעות לסבב הבא (v1.3)

| # | תכונה | למה |
|---|--------|-----|
| 1 | **Stripe / Paybox / Bit אמיתי** + קבלות לפי תקנת רשות המסים | תרומות בפועל |
| 2 | Live Map heatmap של תפילות בעולם (CSS halo + WebSocket) | ויזואלי וויראלי |
| 3 | Yahrzeit auto-reminder (cron יומי שמטריג push) | רגשי, מחזיר משתמשים |
| 4 | תהילים collaborative (חלוקת ספר תהלים אוטומטית בין משתמשים פעילים) | ייחודי |
| 5 | Cantor mode — פתיחת תפילה מעוצבת לחזן בבית הכנסת | use case שני |
| 6 | A/B testing של hero (גוגל אופטימייז) | מקסום המרות |
| 7 | OneSignal alternative — In-App Messages | רטנציה |
| 8 | התחברות עם Apple/Google/Email + PIN | המרת אנונימי לחבר |
| 9 | קולי באתר: "הקדישו בקול" — הקלטות זיכרון | ייחודי, רגשי |
| 10 | תמיכה ב-RTL Arabic + Aramaic snippets | קוסמופוליטי |

תגיד מה דחוף לסבב הבא.
