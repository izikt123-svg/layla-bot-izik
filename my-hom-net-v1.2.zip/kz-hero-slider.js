/* ============================================================
   KZ HERO SLIDER — DEPRECATED
   Replaced by kz-hero-video.js (360° / 4K cinematic banner).
   This file is intentionally a no-op so older HTML that still
   references it doesn't 404. Safe to remove the <script> tag
   for kz-hero-slider.js once all pages are updated.
   ============================================================ */
(function(){ /* intentionally empty */ })();
