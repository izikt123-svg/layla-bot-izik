/* Service Worker — Merkaz HaTfila
   Strategy:
     - Network-first for HTML pages (so updates are visible immediately).
     - Stale-while-revalidate for static assets (CSS/JS/SVG/font).
     - Versioned cache; VERSION bumps invalidate all old caches.
     - Auto-notifies clients when a new SW takes control.
   Bump VERSION every deploy. The clients code in script.js listens
   for "updatefound" and prompts the user to refresh.
*/
const VERSION = 'v1.4.0-2026-05-06';
const STATIC_CACHE = `pc-static-${VERSION}`;
const PAGE_CACHE   = `pc-pages-${VERSION}`;

const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/critical.css',
  '/styles.css',
  '/script.js',
  '/favicon.svg',
  '/manifest.webmanifest',
  '/privacy.html',
  '/terms.html',
  '/accessibility.html',
  '/offline.html'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(STATIC_CACHE).then((cache) =>
      cache.addAll(STATIC_ASSETS).catch(() => {/* tolerate missing optional assets */})
    ).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys
          .filter((k) => !k.endsWith(VERSION))
          .map((k) => caches.delete(k))
      )
    ).then(() => self.clients.claim()).then(() => {
      // Tell every open tab a new version is live so they can show a refresh chip.
      return self.clients.matchAll({ type: 'window' }).then((clients) => {
        clients.forEach((client) => client.postMessage({ type: 'SW_UPDATED', version: VERSION }));
      });
    })
  );
});

function isPageRequest(req) {
  return req.mode === 'navigate' ||
    (req.method === 'GET' && req.headers.get('accept')?.includes('text/html'));
}

function isStaticRequest(url) {
  return /\.(css|js|svg|png|jpg|jpeg|webp|woff2?|ttf|ico|webmanifest)(\?.*)?$/i.test(url.pathname);
}

self.addEventListener('fetch', (event) => {
  const { request } = event;

  if (request.method !== 'GET') return;

  const url = new URL(request.url);

  // Never intercept third-party requests, never intercept Netlify Functions.
  if (url.origin !== self.location.origin) return;
  if (url.pathname.startsWith('/.netlify/functions/')) return;
  if (url.pathname.startsWith('/api/')) return;

  if (isPageRequest(request)) {
    // Network-first: always try fresh HTML, fall back to cache, then offline page.
    event.respondWith(
      fetch(request)
        .then((res) => {
          const copy = res.clone();
          caches.open(PAGE_CACHE).then((c) => c.put(request, copy)).catch(() => {});
          return res;
        })
        .catch(() =>
          caches.match(request).then((cached) => cached || caches.match('/offline.html'))
        )
    );
    return;
  }

  if (isStaticRequest(url)) {
    // Stale-while-revalidate: instant from cache, refresh in background.
    event.respondWith(
      caches.match(request).then((cached) => {
        const fetchPromise = fetch(request).then((res) => {
          const copy = res.clone();
          caches.open(STATIC_CACHE).then((c) => c.put(request, copy)).catch(() => {});
          return res;
        }).catch(() => cached);
        return cached || fetchPromise;
      })
    );
  }
});

self.addEventListener('message', (event) => {
  if (event.data === 'SKIP_WAITING' || event.data?.type === 'SKIP_WAITING') self.skipWaiting();
});

/* ─── Web Push ────────────────────────────────────────────── */
self.addEventListener('push', (event) => {
  let data = {};
  try { data = event.data ? event.data.json() : {}; } catch { data = { title: event.data?.text() || 'מרכז התפילה' }; }
  const title = data.title || 'מרכז התפילה';
  const options = {
    body: data.body || 'יש עדכון חדש בשבילך',
    icon: data.icon || '/favicon.svg',
    badge: data.badge || '/favicon.svg',
    image: data.image,
    tag: data.tag || 'kz-push',
    renotify: !!data.renotify,
    data: { url: data.url || '/', ...(data.data || {}) },
    actions: data.actions || [],
    requireInteraction: !!data.requireInteraction
  };
  event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const url = event.notification.data?.url || '/';
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((wins) => {
      for (const w of wins){
        if (w.url.includes(url.replace(/^\//, '')) && 'focus' in w) return w.focus();
      }
      if (self.clients.openWindow) return self.clients.openWindow(url);
    })
  );
});
