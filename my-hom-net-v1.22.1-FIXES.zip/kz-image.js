/* ============================================================
   KZ IMAGE — smart image loader + Jewish illustration injector
   - Auto-detects [data-kz-illustration="<key>"] and renders SVG.
   - Lazy-loads <img data-kz-src="..."> with placeholder + fade-in.
   - Image upload helper: KZ_IMAGE.upload(file, key) saves a
     downscaled JPEG to localStorage (per-place override).
   - Place card image getter: KZ_IMAGE.forPlace(place) returns:
       1) user-uploaded photo (kz_place_photo_<id>) if exists
       2) place.photo_url if set
       3) Wikipedia image based on place.wiki if set
       4) Smart illustration based on cat (chabad/synagogue/etc)
   ============================================================ */
(function(){
  'use strict';

  const PLACE_PHOTO_KEY = 'kz_place_photo_';

  /* ─── Hero photo registry ───────────────────────────────────
     For each (page or named hero), we list a preferred real photo
     in /images/heroes/. If the file isn't uploaded yet (404), we
     fall back to the matching SVG illustration. */
  const HERO_PHOTOS = {
    soldiers:    { src:'/images/heroes/soldier-kotel.jpg',       fallback:'magenDavid', alt:'חייל מתפלל בכותל' },
    barMitzvah:  { src:'/images/heroes/bar-mitzvah-kotel.jpg',   fallback:'torah',      alt:'משפחה בבר מצווה בכותל' },
    shofar:      { src:'/images/heroes/shofar-mountain.jpg',     fallback:'shofar',     alt:'תקיעת שופר במדבר' },
    jewishLife:  { src:'/images/heroes/jewish-life-collage.jpg', fallback:'jerusalem',  alt:'חיים יהודיים — קולאז\'' },
    wedding:     { src:'/images/heroes/wedding-chuppah.jpg',     fallback:'chuppah',    alt:'חופה תחת כוכבים' }
  };

  const photoCache = {};
  function tryHeroPhoto(name){
    return new Promise((resolve) => {
      const cfg = HERO_PHOTOS[name];
      if (!cfg) return resolve(null);
      if (photoCache[name] !== undefined) return resolve(photoCache[name]);
      const img = new Image();
      img.onload  = () => { photoCache[name] = cfg.src; resolve(cfg.src); };
      img.onerror = () => { photoCache[name] = null;     resolve(null); };
      img.src = cfg.src;
    });
  }

  /* Render hero photo into element. If photo doesn't exist → SVG fallback. */
  async function renderHero(el, name){
    if (!el) return;
    const cfg = HERO_PHOTOS[name];
    if (!cfg) return;
    el.setAttribute('aria-label', cfg.alt || '');
    const photo = await tryHeroPhoto(name);
    if (photo){
      el.style.backgroundImage = `url("${photo}")`;
      el.style.backgroundSize = 'cover';
      el.style.backgroundPosition = 'center';
      el.dataset.kzHeroSource = 'photo';
    } else if (cfg.fallback){
      const svgUrl = getIllustration(cfg.fallback, 1200, 600);
      if (svgUrl){
        el.style.backgroundImage = `url("${svgUrl}")`;
        el.style.backgroundSize = 'cover';
        el.style.backgroundPosition = 'center';
        el.dataset.kzHeroSource = 'svg';
      }
    }
    if (!el.style.minHeight) el.style.minHeight = '260px';
  }

  /* Auto-render: any element with data-kz-hero="<name>" gets the photo */
  function autoRenderHeroes(){
    document.querySelectorAll('[data-kz-hero]').forEach(el => {
      if (el.dataset.kzRendered === '1' && el.dataset.kzHeroSource) return;
      const name = el.dataset.kzHero;
      renderHero(el, name).then(() => { el.dataset.kzRendered = '1'; });
    });
  }

  function getIllustration(key, w, h){
    if (!window.KZ_ILLUSTRATIONS) return null;
    const fn = window.KZ_ILLUSTRATIONS[key];
    return fn ? fn({ w, h }) : null;
  }

  function categoryIllustration(cat){
    const map = {
      chabad: 'chabadHouse',
      synagogue: 'synagogue',
      tomb: 'rachel',
      holy: 'kotel',
      jcc: 'magenDavid',
      embassy: 'magenDavid',
      kosher: 'challah',
      mikveh: 'magenDavid',
      yeshiva: 'torah'
    };
    return map[cat] || 'magenDavid';
  }

  function loadJson(key, def){
    try { return JSON.parse(localStorage.getItem(key) || JSON.stringify(def)); }
    catch { return def; }
  }
  function saveJson(key, val){ try { localStorage.setItem(key, JSON.stringify(val)); } catch {} }

  function getUserPhoto(placeId){
    if (!placeId) return null;
    return localStorage.getItem(PLACE_PHOTO_KEY + placeId);
  }
  function setUserPhoto(placeId, dataUrl){
    if (!placeId) return;
    try { localStorage.setItem(PLACE_PHOTO_KEY + placeId, dataUrl); } catch {}
  }
  function clearUserPhoto(placeId){
    if (!placeId) return;
    try { localStorage.removeItem(PLACE_PHOTO_KEY + placeId); } catch {}
  }

  /* Read a file and downscale to maxWidth, return data URL JPEG */
  function readDownscaled(file, maxWidth=720, quality=0.78){
    return new Promise((resolve, reject) => {
      const r = new FileReader();
      r.onload = () => {
        const img = new Image();
        img.onload = () => {
          const ratio = img.width > maxWidth ? maxWidth / img.width : 1;
          const w = Math.round(img.width * ratio);
          const h = Math.round(img.height * ratio);
          const c = document.createElement('canvas');
          c.width = w; c.height = h;
          c.getContext('2d').drawImage(img, 0, 0, w, h);
          resolve(c.toDataURL('image/jpeg', quality));
        };
        img.onerror = reject;
        img.src = r.result;
      };
      r.onerror = reject;
      r.readAsDataURL(file);
    });
  }

  /* Smart picker: returns the best available image source for a place */
  function forPlace(place){
    if (!place) return null;
    const user = getUserPhoto(place.id);
    if (user) return user;
    if (place.photo_url) return place.photo_url;
    return getIllustration(categoryIllustration(place.cat), 600, 400);
  }

  /* Auto-render: any element with data-kz-illustration="<key>" gets the SVG */
  function autoRender(){
    document.querySelectorAll('[data-kz-illustration]').forEach(el => {
      if (el.dataset.kzRendered) return;
      const key = el.dataset.kzIllustration;
      const w = parseInt(el.dataset.w || el.getAttribute('width') || el.clientWidth || 600, 10);
      const h = parseInt(el.dataset.h || el.getAttribute('height') || el.clientHeight || 400, 10);
      const url = getIllustration(key, w, h);
      if (!url) return;
      if (el.tagName === 'IMG'){
        el.src = url;
      } else {
        el.style.backgroundImage = `url("${url}")`;
        el.style.backgroundSize = 'cover';
        el.style.backgroundPosition = 'center';
        if (!el.style.minHeight) el.style.minHeight = h + 'px';
      }
      el.dataset.kzRendered = '1';
    });
  }

  /* Lazy load <img data-kz-src="..."> when visible */
  function lazyLoad(){
    if (!('IntersectionObserver' in window)){
      document.querySelectorAll('img[data-kz-src]').forEach(img => {
        img.src = img.dataset.kzSrc;
        img.removeAttribute('data-kz-src');
      });
      return;
    }
    const io = new IntersectionObserver((entries) => {
      entries.forEach(e => {
        if (!e.isIntersecting) return;
        const img = e.target;
        const src = img.dataset.kzSrc;
        if (src){
          img.src = src;
          img.classList.add('kz-img-loaded');
        }
        img.removeAttribute('data-kz-src');
        io.unobserve(img);
      });
    }, { rootMargin: '200px' });
    document.querySelectorAll('img[data-kz-src]').forEach(img => io.observe(img));
  }

  function init(){
    autoRender();
    autoRenderHeroes();
    lazyLoad();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, { once: true });
  else init();

  /* Re-run on DOM changes (best-effort) */
  if ('MutationObserver' in window){
    const mo = new MutationObserver(() => { autoRender(); autoRenderHeroes(); lazyLoad(); });
    mo.observe(document.body || document.documentElement, { childList: true, subtree: true });
  }

  /* Public API */
  window.KZ_IMAGE = {
    illustration: getIllustration,
    categoryIllustration,
    forPlace,
    upload: async (file, placeId) => {
      const url = await readDownscaled(file, 720, 0.78);
      if (placeId) setUserPhoto(placeId, url);
      return url;
    },
    clearUserPhoto,
    getUserPhoto,
    rerender: () => { autoRender(); autoRenderHeroes(); lazyLoad(); },
    renderHero,
    HERO_PHOTOS
  };
})();
