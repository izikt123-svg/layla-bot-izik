# 🕯 מרכז התפילה · my-hom.net

> **הבית היהודי שלך בעולם** — אתר תפילה, קהילה, חיים יהודיים, וטיולים. בנוי בקפידה לאישה, לאיש, לילד, ולמשפחה — בכל יום ובכל שעה, בכל פינה בעולם.

---

## 🚀 הפעלה מהירה (3 דקות)

### 🅰️ העלאה ל-Netlify (המלצה — חינם, מהיר):
1. גרור את התיקיה הזו (אחרי שחילצת את ה-ZIP) ל-https://app.netlify.com
2. הגדר env vars (ראה למטה)
3. דומיין: my-hom.net (או כל דומיין אחר)
4. **זהו** — האתר חי.

### 🅱️ העלאה ל-Hostinger / כל אחסון רגיל:
1. העלה את כל הקבצים ל-`public_html/`
2. SSL פעיל אוטומטית
3. ללא Netlify Functions: API features (AI, Push, etc.) לא יעבדו, אבל כל השאר עובד מקומית

---

## 🔑 משתני סביבה (Netlify dashboard → Site settings → Environment)

### חובה לפיצ'רים מתקדמים:
```
GEMINI_API_KEY        מ-https://aistudio.google.com/apikey  (מירב AI + תרגום + Vision)
SUPABASE_URL          מ-Supabase Project Settings           (Push, Counter, Wall, Candles)
SUPABASE_SERVICE_KEY  service_role key (לא anon!)
```

### ל-Push Notifications:
```
VAPID_PUBLIC          מ-`npx web-push generate-vapid-keys`
VAPID_PRIVATE
VAPID_SUBJECT         mailto:you@my-hom.net
PUSH_SECRET           מחרוזת אקראית ארוכה
```

### ל-Stripe (תרומות אמיתיות):
```
STRIPE_SECRET_KEY     מ-https://dashboard.stripe.com/apikeys
SITE_URL              https://my-hom.net
```

ב-`index.html` (או דף הבית) להוסיף:
```html
<script>
  window.KZ_SUPABASE_URL  = 'https://YOUR.supabase.co';
  window.KZ_SUPABASE_ANON = 'eyJ…';
  window.KZ_VAPID_PUBLIC  = 'YOUR_VAPID_PUBLIC';
  window.KZ_HERO_VIDEO_URL = 'https://www.youtube.com/watch?v=YOUR_360_VIDEO';
  window.KZ_DONATE_CFG = { /* PayPal, Bit, Paybox, bank */ };
</script>
```

---

## 🗄 SQL — להריץ פעם אחת ב-Supabase

```sql
-- Push subscriptions
create table push_subscriptions (
  id uuid primary key default gen_random_uuid(),
  endpoint text unique not null,
  p256dh text not null, auth text not null,
  lang text default 'he', created_at timestamptz default now()
);

-- Live praying counter
create table prayer_heartbeats (
  sid text primary key, at timestamptz default now()
);

-- Yahrzeit reminders (cron)
create table yahrzeits (
  id uuid primary key default gen_random_uuid(),
  user_id uuid, endpoint text,
  deceased_name text not null,
  hebrew_date_day int not null,
  hebrew_date_month text not null,
  created_at timestamptz default now()
);

-- Collaborative Tehilim
create table tehillim_sessions (
  id text primary key,
  done int[] default '{}', in_progress int[] default '{}',
  updated_at timestamptz default now()
);

-- Shabbat hospitality
create table shabbat_hospitality (
  id uuid primary key default gen_random_uuid(),
  kind text check (kind in ('host','guest')) not null,
  name text, contact text not null,
  city text, country text, lat numeric, lng numeric,
  date_start date, notes text,
  created_at timestamptz default now()
);

-- Virtual Shabbat candles wall
create table shabbat_candles_live (
  id uuid primary key default gen_random_uuid(),
  name text not null, prayer text, city text, city_id text,
  likes int default 0, audio_url text, photo_url text,
  lat numeric, lng numeric,
  candle_at timestamptz, havdala_at timestamptz,
  created_at timestamptz default now()
);
create index on shabbat_candles_live (havdala_at);

-- "Light for me" requests
create table candle_requests (
  id uuid primary key default gen_random_uuid(),
  for_name text not null, prayer text,
  claimed_by text, claimed_city text, claimed_at timestamptz,
  created_at timestamptz default now()
);

-- Simchas
create table simchas (
  id uuid primary key default gen_random_uuid(),
  type text not null, who_name text not null,
  city text, event_date date, message text,
  blessings int default 0, created_at timestamptz default now()
);

-- Year-round prayer wall
create table prayer_wall (
  id uuid primary key default gen_random_uuid(),
  cat text not null, for_name text not null, text text,
  posted_by text default 'אנונימית',
  prayers int default 0, created_at timestamptz default now()
);
```

---

## 📁 מבנה הפרויקט

### דפים עיקריים (24)
| דף | תיאור |
|----|--------|
| `home.html` | 🏠 **דשבורד הבית** — מסך פתיחה מאוחד time-of-day-aware |
| `morning.html` | 🌅 בוקר טוב להשם — מודה אני, ברכות, כוונה יומית |
| `moment.html` | ✦ 60 שניות עם הקב"ה — טקס יומי |
| `daily-tehilim.html` | 📿 תהילים יומי |
| `daily-learning.html` | 📚 לימוד יומי (פרשה / דף יומי / הלכה / מצווה) |
| `prayer-wall.html` | 🙏 קיר בקשות תפילה ציבורי |
| `soldiers.html` | 🎗 תפילה לחיילי צה"ל / שבויים / פצועים |
| `shabbat-candles.html` | 🕯 הדלקת נרות שבת + קיר נרות חי |
| `candles-cinema.html` | 📺 קיר נרות במסך מלא |
| `candles-map.html` | 🗺 מפת נרות חיה בעולם |
| `pray-along.html` | 🤝 חדר תפילה משותף (WebRTC) |
| `cantor.html` | 🎤 מצב חזן — טקסט גדול |
| `simchas.html` | 🎉 שמחות (חתונה / ברית / בר מצווה) |
| `mourners.html` | 🕯 לוח אבלים — 12 חודשים מלאים |
| `family-archive.html` | 📖 הספר שלנו — ארכיון משפחתי אישי |
| `kids-bedtime.html` | 🌙 12 סיפורי תנ"ך לילדים |
| `world.html` | 🌍 הבית היהודי בעולם — אטלס + מפה |
| `traveler.html` | 🧭 מצב מטייל (NearMe / Emergency / Hospitality) |
| `shabbat-recipes.html` | 🍞 40 מתכוני שבת מ-8 עדות |
| `my-journey.html` | 👤 המסע שלי — דשבורד אישי |
| `illustrations.html` | 🎨 גלריית 15 איורים |

### Netlify Functions (15)
- `/api/ai`, `/api/translate`, `/api/compose`, `/api/menu-vision` (Gemini)
- `/api/push-subscribe`, `/api/push-unsubscribe`, `/api/push-send` (VAPID)
- `/api/counter`, `/api/heatmap`, `/api/tehillim` (Live)
- `/api/candles`, `/api/candle-requests`, `/api/prayer-wall`, `/api/simchas`, `/api/hospitality`
- `/api/donate-stripe`, `/api/og-image`
- `/api/yahrzeit-cron`, `/api/friday-push` (Scheduled)

### נתונים
- `data/jewish-places.js` — 497 מקומות בסיסיים
- `data/chabad-verified.js` — **81 בתי חב"ד מאומתים** ע"י איציק
- `data/jcc-verified.js` — 7 קהילות ישראליות
- `data/embassies-verified.js` — 10 שגרירויות ישראל
- `data/world-index.js` — 62 מדינות + יבשות + טלפונים
- `data/shabbat-recipes.js` — 40 מתכונים מ-8 עדות
- `data/halachot-mitzvot.js` — 15 הלכות + 15 מצוות
- `data/kids-stories.js` — 12 סיפורי תנ"ך
- `data/jewish-illustrations.js` — 15 SVG illustrations

### תמונות hero
תיקיית `images/heroes/` — תכניס לשם 5 תמונות עם השמות:
- `soldier-kotel.jpg`
- `bar-mitzvah-kotel.jpg`
- `shofar-mountain.jpg`
- `jewish-life-collage.jpg`
- `wedding-chuppah.jpg`

ראה `images/heroes/README.md` לפרטים.

### WhatsApp Bot
`whatsapp-bot/` — בוט מירב לוואטסאפ.
```bash
cd whatsapp-bot
npm install
SITE_URL=https://my-hom.net npm start
```

---

## 🎨 עיצוב + נגישות

- **תפריט גלובלי**: כפתור hamburger בכל דף → drawer עם 24 דפים מסווגים + חיפוש
- **רספונסיביות מלאה**: iPhone SE → 4K TV
- **תמיכה ב-RTL** מלאה
- **Dark/Light/Auto theme** (`/index.html` → ☾/☀/◐ toggle)
- **Reduced motion** מכובד
- **Touch targets** מינימום 44px במובייל
- **Keyboard navigation** מלא + focus visible
- **Print friendly** למתכונים, לוח אבלים, וכו'

---

## ⚡ Service Worker
- Network-first ל-HTML (תמיד גרסה טרייה)
- Stale-while-revalidate ל-CSS/JS
- Auto-update chip ("✦ גרסה חדשה — לחץ לרענון")
- Push handler מובנה
- Offline fallback ל-`offline.html`

**כל פעם שאתה מעלה גרסה חדשה — בדוק את `sw.js` שורה 10 (`VERSION`) ועדכן אותה.**

---

## 📜 רישוי
פרויקט אישי של **איציק** (איזיק) למרכז התפילה / my-hom.net.
כל המקורות הציבוריים (Hebcal, Sefaria, Chabad.org, OpenStreetMap) מצוטטים בקבצים הרלוונטיים.

---

## 🌟 גרסת בנייה
**v1.20.0** · 2026-05-06 · 20+ סבבי שדרוג

✦
