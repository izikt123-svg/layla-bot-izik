# 🌟 גרסה v1.5 — מרכז התפילה / my-hom.net

## ✨ 6 תכונות חדשות

### 1. ✦ AI Prayer Composer — מירב כותבת תפילה
- כפתור `class="js-kz-compose" data-target="#prayerText"` פותח מודל יפה.
- הזן כוונה (רפואה/פרנסה/...), שם, פרטים, אורך, ושפה.
- מירב מנסחת תפילה אישית עם פסוקים מתהלים.
- 3 הצעות פתיחה אלטרנטיביות.
- כפתור "השתמש" מזריק ישר ל-`<textarea>`.

### 2. 📅 Calendar Widget
- היומן היהודי המלא — עברית, פרשה, דף יומי, הדלקת נרות, צאת השבת, מועד הבא.
- בחירת עיר (14 ערים מובנות, ניתן להרחיב).
- אוטומטי דרך Hebcal API (חינם, ללא מפתח).
- מתחבר ל-`<div data-kz-calendar></div>` בכל מקום.

### 3. 🌗 Dark/Light Theme Toggle
- כפתור עגול קבוע בפינה (`☾ / ☀ / ◐`).
- מחזורי 3 מצבים: Dark → Light → Auto.
- בחירה נשמרת ב-localStorage.
- מאזין לשינויי `prefers-color-scheme` במצב Auto.

### 4. 🌐 i18n OG Image
- תמונת ה-OG עכשיו תומכת ב-8 שפות: he, en, fr, es, ru, ar, pt, de.
- `kz-share.js` שולח אוטומטית את שפת הדף.
- RTL נתמך לערבית ועברית.

### 5. ⚡ Lighthouse 95+ Pack
- `kz-perf.js`:
  - Lazy-load לכל ה-`<img>` ללא loading attribute.
  - Decode async + lazy iframes.
  - Idle prefetch של עמודי קישור על hover/touchstart.
  - הסרת אנימציות כבדות במכשירים קטנים מאוד.
- `decoding="async"` נוסף לכל התמונות.

### 6. 🤝 Pray-Along — תפילה משותפת חיה
- עמוד `/pray-along.html` חדש.
- חדרי תפילה משותפים עם **Supabase Realtime presence**.
- **WebRTC voice** (mesh, עד 8 משתתפים).
- חיווי "מי מדבר עכשיו" (animation pulse).
- שיתוף URL עם `?room=NAME` להצטרפות בקליק.
- Mute/Unmute / Leave.
- STUN: stun.l.google.com.

---

## 🔧 הגדרות חדשות

`index.html` — וידוא:
```html
<script>
  window.KZ_SUPABASE_URL  = '...'; // נדרש ל-Pray-Along + Auth
  window.KZ_SUPABASE_ANON = '...';
</script>
```

ב-`memorial.html` או טופס בקשת תפילה, הוסף איפה שיש `<textarea>`:
```html
<button class="js-kz-compose" data-target="#prayerText">✦ עזור לי לנסח</button>
<textarea id="prayerText"></textarea>
```

ב-עמוד הבית או לוח שבועי, הוסף את היומן:
```html
<div data-kz-calendar></div>
```

---

## 📁 קבצים חדשים

```
+ kz-compose.js / .css        (AI prayer composer modal)
+ kz-calendar.js / .css       (Daily Jewish info widget)
+ kz-theme.js / .css          (Dark/Light/Auto)
+ kz-perf.js                  (Lighthouse pack)
+ pray-along.html
+ kz-pray-along.js / .css     (WebRTC room)
+ netlify/functions/compose.js (Gemini prayer drafter)
~ netlify/functions/og-image.js (i18n: 8 langs + RTL)
~ kz-share.js                 (auto-detect lang)
~ manifest.webmanifest        (+ pray-along shortcut)
~ index.html                  (script/CSS refs)
~ netlify.toml                (+ /api/compose)
~ sw.js                       (VERSION → v1.5.0)
```

---

## 🎯 v1.6 הצעות

1. **Yad2-style mitzvah marketplace** — תרומת חפצים פיזיים
2. **Prayer streaks** — Duolingo-style: 7 ימים ברצף
3. **Voice-to-prayer** — מקליטים סיפור, מירב הופכת לתפילה
4. **AI translate ה-Tehillim** עצמו לפי שפת המשתמש
5. **Live Shabbat counter** — countdown לכניסת השבת בעיר שלך
6. **Group fundraising** — קמפיינים שיתופיים לחולה / משפחה נצרכת
7. **Daf Yomi audio** — שיעור יומי מובנה
8. **Apple Wallet pass** עם זמני תפילה לעיר שלך
9. **Cantor Mode v2** — sync עם Pray-Along (חזן מוביל מרחוק)
10. **Lighthouse audit run** — דוח אמיתי + תיקונים נוספים

תגיד "ממשיכים v1.6" עם מה שדחוף.
