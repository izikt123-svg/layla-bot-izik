# 🌟 גרסה v1.3 — מרכז התפילה / my-hom.net

## ✨ 5 תכונות בקנה מידה בינלאומי

### 1. 🌍 Heatmap עולמי חי
- מפת עולם בקנבס עם הילות פועמות במקום שבו תפילות מתקיימות.
- 40 ערים בברירת מחדל; משדרג אוטומטית כשמחובר ל-Supabase (`prayers` table).
- Function: `/api/heatmap` (אגרגציה לפי 24 שעות אחרונות).
- **ויראלי** — אנשים יצלמו ויפיצו.

### 2. 🕯 Yahrzeit Auto-Reminder
- Netlify Scheduled Function רץ **כל יום ב-06:00 UTC** (≈ 09:00 IST).
- מתרגם את התאריך לעברי דרך Hebcal API.
- שולח push למחזיקי הרשמה: היום / מחר / בעוד שבוע.
- כפתור clickthrough ל-`memorial.html`.

### 3. 📖 ספר תהלים שיתופי
- כל מצטרף מקבל אוטומטית 2 פרקים שלא נקראו עדיין.
- כששלמו 150 → אנימציית "השלמנו ספר תהלים יחד 🌟".
- מתסנכרן בזמן אמת בין כל המצטרפים (polling 20s).
- Function: `/api/tehillim` (claim/complete/state).

### 4. 🎙 הקדשה בקול
- הקלטה ישירה בדפדפן (≤ 60 שניות) עם meter ויזואלי.
- שמירה מקומית + העלאה אופציונלית ל-Supabase Storage.
- Audio player לכל הקדשה, מחיקה אישית.
- מתאים לעמוד `memorial.html` או כל מקום עם `[data-kz-voice-memorial]`.

### 5. 💝 Donate Modal — מערכת תשלומים מלאה
- מודל יפהפה עם **6 שיטות תשלום**:
  - 💳 **Stripe Checkout** — אוטומטית מנפיקה קבלות (USD/EUR/ILS)
  - 📱 **Bit** — מספר טלפון + העתקה
  - 💼 **Paybox** — לינק ישיר
  - 🕎 **נדרים פלוס** — לקבלת מס 46א
  - 🌐 **PayPal.me** — לתורמי חו"ל
  - 🏦 **העברה בנקאית** — פרטים מלאים
- 6 סכומים מוכנים: 18, 36, 72, 180, 360, 720 ש"ח + סכום אחר.
- כל אלמנט עם class `js-kz-donate` או `KZ_DONATE.open()` יפתח את המודל.

---

## 🔧 SQL חדש ב-Supabase

```sql
-- For collaborative Tehillim
create table tehillim_sessions (
  id text primary key,
  done int[] default '{}',
  in_progress int[] default '{}',
  updated_at timestamptz default now()
);

-- For yahrzeit reminders
create table yahrzeits (
  id uuid primary key default gen_random_uuid(),
  user_id uuid,
  endpoint text,
  deceased_name text not null,
  hebrew_date_day int not null,
  hebrew_date_month text not null,
  leap_aware boolean default true,
  created_at timestamptz default now()
);

-- For heatmap aggregation (extend prayers table if exists)
alter table prayers add column if not exists lat numeric;
alter table prayers add column if not exists lng numeric;
alter table prayers add column if not exists city text;
```

---

## 🌐 Env vars חדשים ב-Netlify

```
STRIPE_SECRET_KEY      ← מ-https://dashboard.stripe.com/apikeys
STRIPE_PRICE_CURRENCY  ← אופציונלי, ברירת מחדל 'ils'
SITE_URL               ← https://my-hom.net (לכתובות החזרה של Stripe)
```

ושימוש קיים מ-v1.2: `GEMINI_API_KEY`, `SUPABASE_URL`, `SUPABASE_SERVICE_KEY`, `VAPID_*`, `PUSH_SECRET`.

---

## 📁 קבצים חדשים

```
+ kz-heatmap-globe.js / .css       (Live world map)
+ kz-tehillim-split.js / .css      (Collaborative Psalms)
+ kz-voice-memorial.js / .css      (Audio dedications)
+ kz-donate.js / .css              (Multi-rail donation modal)
+ netlify/functions/heatmap.js
+ netlify/functions/tehillim.js
+ netlify/functions/yahrzeit-cron.js  (scheduled daily 06:00 UTC)
+ netlify/functions/donate-stripe.js
~ index.html                       (script/CSS + window.KZ_DONATE_CFG)
~ netlify.toml                     (4 new redirects)
~ sw.js                            (VERSION → v1.3.0)
```

---

## 🎯 מה לעשות אחרי הפריסה

1. הרץ `npx web-push generate-vapid-keys` והדבק ב-Netlify env vars.
2. הרץ את ה-SQL החדשים ב-Supabase.
3. ערוך `index.html` שורת `KZ_DONATE_CFG` — מלא Bit, Paybox וכו'.
4. אחרי שיש לך Stripe key — שנה `stripeEnabled: true` ב-`KZ_DONATE_CFG`.
5. **בדיקה:** הקלק `🕯 תרומה` כדי לוודא שהמודל נפתח, גם בלי Stripe.

---

## 🚀 רעיונות לסבב v1.4 (כשתגיד "ממשיכים")

- **Apple/Google/Email Sign-in** עם PIN (Supabase Auth).
- **Cantor Mode** — מסך ייעודי לחזן (טקסט גדול, אוטופלוס לתפילות).
- **Heatmap עם trails** — קווים קלים בין ערים לחבר ביניהן.
- **WhatsApp deep-link** לכל בקשת תפילה.
- **Hebcal widget מובנה** — פרשה, זמני שבת, מעובדים מקומית.
- **PWA Shortcuts** — קיצורי דרך מהמסך הראשי (Quick prayer, Yahrzeit).
- **OG Image dynamic** — תמונה מותאמת לכל בקשת תפילה (לשיתוף חברתי).
- **Performance budget** — Lighthouse 95+ בכל קטגוריה.
- **Accessibility audit** — WCAG AA full pass.
- **Offline mode** — אזור אישי + בקשות שלי זמינות גם בלי רשת.
