# 🌍 גרסה v1.6 — Traveler Mode

## 💛 הסיפור מאחורי הסבב הזה
איציק שאל אותי שאלה חכמה: *"אם את מטיילת בארץ או יהודייה בחו"ל — מה היית רוצה מהאתר?"*

הסבב הזה הוא **התשובה שלי**.

---

## ✨ 9 פיצ'רים חדשים

### 🧭 דשבורד `/traveler.html`
מסך מאוחד שכולל הכל. נכנסים פעם אחת, מעניקים מיקום, ואז כל המודולים מתעוררים יחד.

### 1. 📍 NearMe Radar
- **מקומות סביבך עכשיו** — חב"ד, בתי כנסת, מסעדות כשרות, מקוואות, קברי צדיקים.
- **מיון לפי מרחק הליכה** (Haversine).
- **סטטוס "פתוח עכשיו"** למסעדות (heuristic — סגור בשבת + ערב שישי).
- **כפתור Waze + שיתוף וואטסאפ** לכל מקום.
- **augmentation מ-Overpass API** — מקבל גם מקומות יהודיים מ-OpenStreetMap בזמן אמת.

### 2. 🚨 Emergency Button
**הכפתור החשוב ביותר באתר.**
- **בית חב"ד הקרוב** + Waze.
- **מספרי חירום מקומיים** לפי מדינה: MDA / Hatzalah / משטרה / שגרירות ישראל.
- **שיתוף מיקום במהירות** למשפחה דרך וואטסאפ.
- 9 מדינות מובנות (IL, US, GB, FR, DE, AU, CA, AR, BR) + fallback 112.

### 3. 🕯 Geo Shabbat Alert
- **התראת push 18 דקות לפני כניסת השבת** במיקום שלך.
- מחושב אוטומטית דרך Hebcal API לפי הקואורדינטות שלך.
- Toggle פשוט במסך — ההתראה משתמשת ב-SW אם יש הרשאה, אחרת banner מקומי.

### 4. 🏠 Shabbat Hospitality
- **מערכת אירוח שבת**: "אני מארח/ת" / "מחפש/ת אירוח".
- שמירה ב-Supabase (`shabbat_hospitality` table).
- כפתור "צור קשר" — פותח וואטסאפ ישירות.
- **Fallback אם אין Supabase**: מפרסם בוואטסאפ פתוח לקבוצות ציבוריות.

### 5. 💱 Multi-Currency Tzedakah
- שדה סכום + 14 מטבעות (ILS, USD, EUR, GBP, BRL, ARS, מקסיקני, יפני, רובל, באט, רופי, ועוד).
- **שערים חיים** מ-`open.er-api.com` (חינם, ללא מפתח).
- מציג שווי בש"ח + USD בזמן אמת.
- 3 presets: 18, 36, 180 (במטבע המקומי).
- כפתור תרומה — מזריק את הסכום למודל הקיים של הדונציות.

### 6. 📷 Menu Translator + Kosher Detector
- **מצלם תפריט** (`<input type="file" capture>`) → Gemini Vision.
- מתרגם לעברית/אנגלית/רוסית/ספרדית.
- **מזהה פריטים בעייתיים** (חזיר, פירות ים, בשר וחלב, ג'לטין מהחי).
- מציג אזהרות צבעוניות + הודעת "✓ לא זוהו פריטים בעייתיים" אם הכל נקי.

### 7. 🕯 Tzaddik GPS Audio Tour
- כשאתה במרחק 200מ' מקבר צדיק / אתר קדוש — **קופץ כרטיס יפה** עם:
  - שמו וסיפור קצר.
  - **כפתור "האזן"** — TTS בעברית.
  - **כפתור "בקש תפילה כאן"** — מפנה לטופס בקשה ממוקד.
- מעקב geolocation continuous בזמן הליכה.
- 7 סיפורים מובנים (רשב"י, רחל, מערת המכפלה, האר"י, רמב"ם, באבא סאלי, הרבי מליובאוויטש).

### 8. 📱 City Community Connect
- **קישורים ישירים לקהילות יהודיות מקומיות** (WhatsApp / Telegram / Facebook) ב-14 ערים מובילות.
- אם העיר לא ברשימה — כפתור "🔍 חפש בגוגל" עם query מוכן.

### 9. ✈️ אינדיקטור "בארץ / בעולם"
ה-pill למעלה משתנה אוטומטית: **🇮🇱 מטייל/ת בישראל** או **✈️ יהודי/ה בעולם** — לפי מדינת המיקום שזוהה.

---

## 🗄️ SQL חדש ב-Supabase

```sql
create table shabbat_hospitality (
  id uuid primary key default gen_random_uuid(),
  kind text not null check (kind in ('host','guest')),
  name text,
  contact text not null,
  city text,
  country text,
  lat numeric, lng numeric,
  date_start date,
  date_end date,
  notes text,
  created_at timestamptz default now()
);
alter table shabbat_hospitality enable row level security;
create policy "anyone can read" on shabbat_hospitality for select using (true);
```

---

## 📁 קבצים חדשים

```
+ traveler.html
+ kz-traveler.js / .css
+ kz-traveler-modules.css       (משותף לכל המודולים)
+ kz-near-me.js / .css
+ kz-emergency.js
+ kz-shabbat-alert.js
+ kz-hospitality.js
+ kz-tzedakah-fx.js
+ kz-menu-translator.js
+ kz-tzaddik-tour.js / .css
+ kz-city-community.js
+ netlify/functions/hospitality.js
+ netlify/functions/menu-vision.js
~ manifest.webmanifest          (+ shortcut למצב מטייל)
~ netlify.toml                  (3 redirects חדשים)
~ sw.js                         (VERSION → v1.6.0)
```

---

## 🚀 v1.7 הצעות

1. **Pray-Along ↔ Cantor sync** — חזן מוביל מרחוק, כולם רואים אותו פרק
2. **Daf Yomi audio player** — שיעור יומי מובנה
3. **Apple Wallet pass** עם זמני תפילה לעיר שלך
4. **Group Fundraising** — קמפיינים שיתופיים
5. **Voice → Prayer** — מקליט סיפור, מירב הופכת לתפילה
6. **Streaks** — Duolingo-style 7 ימים ברצף
7. **Kosher delivery integrations** (DoorDash/Wolt/Glovo)
8. **Tzaddik tour expansion** — לפחות 30 קברים עם סיפורים מובנים

תגיד "ממשיכים v1.7" עם מה שדחוף.
