/* ============================================================
   KZ HERO VIDEO — 360° / 4K cinematic hero banner
   Replaces kz-hero-slider.js. Inserts an immersive video
   banner above the topbar (same mounting point the slider used).

   Configure your video by setting window.KZ_HERO_VIDEO before
   this script loads, or edit DEFAULT_CONFIG below:

   <script>
     window.KZ_HERO_VIDEO = {
       provider: 'youtube',     // 'youtube' | 'mp4'
       id: 'YOUTUBE_VIDEO_ID',  // 360 video id (e.g. Jerusalem 360 4K)
       mp4Url: '',              // alternative: direct .mp4 url
       poster: '/path/to/hero-poster.jpg',
       muted: true,
       loop: true,
       title: 'הר הבית · ירושלים 360°'
     };
   </script>
   ============================================================ */
(function(){
  'use strict';

  // Default: a curated 360° Jerusalem clip. Swap freely — paste any YouTube link.
  // The code below auto-extracts the video ID from any of these formats:
  //   https://www.youtube.com/watch?v=ABCD1234
  //   https://youtu.be/ABCD1234
  //   https://www.youtube.com/embed/ABCD1234
  //   ABCD1234   (raw id)
  const DEFAULT_CONFIG = {
    provider: 'illustration',   // ← 'illustration' / 'youtube' / 'mp4'
    illustration: 'jerusalem',  // SVG illustration key from data/jewish-illustrations.js
    url: '',                    // YouTube URL — only used if provider='youtube'
    id: '',                     // auto-derived
    mp4Url: '',
    poster: '',
    muted: true,
    loop: true,
    title: 'מרכז התפילה · ירושלים'
  };

  // Accept either KZ_HERO_VIDEO or KZ_HERO_VIDEO_URL (a plain URL string)
  const userCfg = (typeof window.KZ_HERO_VIDEO === 'string')
    ? { url: window.KZ_HERO_VIDEO }
    : (window.KZ_HERO_VIDEO || {});
  if (typeof window.KZ_HERO_VIDEO_URL === 'string') userCfg.url = window.KZ_HERO_VIDEO_URL;

  const cfg = Object.assign({}, DEFAULT_CONFIG, userCfg);

  // Extract a YouTube video id from any common URL form
  function extractYouTubeId(input){
    if (!input) return '';
    const s = String(input).trim();
    if (/^[\w-]{8,15}$/.test(s)) return s;        // looks like a raw id
    try {
      const u = new URL(s, location.href);
      if (u.hostname.includes('youtu.be')) return u.pathname.slice(1).split('/')[0];
      if (u.hostname.includes('youtube.com')){
        if (u.pathname === '/watch') return u.searchParams.get('v') || '';
        const m = u.pathname.match(/\/(embed|shorts|live)\/([\w-]{8,15})/);
        if (m) return m[2];
      }
    } catch {}
    return '';
  }

  if (!cfg.id) cfg.id = extractYouTubeId(cfg.url);

  function buildBanner(){
    if (document.querySelector('.kz-hero-video')) return;

    const wrap = document.createElement('div');
    wrap.className = 'kz-hero-video';
    wrap.setAttribute('aria-label', cfg.title);

    if (cfg.provider === 'youtube' && cfg.id){
      // YouTube has native 360° support. Drag to look around.
      const params = new URLSearchParams({
        autoplay: '1',
        mute: cfg.muted ? '1' : '0',
        loop: cfg.loop ? '1' : '0',
        playlist: cfg.id,         // required for loop on YouTube
        controls: '1',
        modestbranding: '1',
        rel: '0',
        playsinline: '1',
        iv_load_policy: '3'
      });
      wrap.innerHTML = `
        <div class="kz-hv-shell">
          <iframe
            class="kz-hv-frame"
            src="https://www.youtube-nocookie.com/embed/${encodeURIComponent(cfg.id)}?${params}"
            title="${escapeHtml(cfg.title)}"
            loading="lazy"
            allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
            allowfullscreen
            referrerpolicy="strict-origin-when-cross-origin"></iframe>
          <div class="kz-hv-vignette" aria-hidden="true"></div>
          <div class="kz-hv-caption">
            <span class="kz-hv-pill">🌍 360°</span>
            <span class="kz-hv-title">${escapeHtml(cfg.title)}</span>
            <span class="kz-hv-hint">גרור כדי להסתכל סביב</span>
          </div>
        </div>`;
    } else if (cfg.mp4Url){
      // Self-hosted MP4 fallback (no 360 panning, but cinematic).
      wrap.innerHTML = `
        <div class="kz-hv-shell">
          <video
            class="kz-hv-video"
            ${cfg.muted ? 'muted' : ''}
            ${cfg.loop ? 'loop' : ''}
            autoplay playsinline preload="metadata"
            ${cfg.poster ? `poster="${escapeAttr(cfg.poster)}"` : ''}>
            <source src="${escapeAttr(cfg.mp4Url)}" type="video/mp4">
          </video>
          <div class="kz-hv-vignette" aria-hidden="true"></div>
          <div class="kz-hv-caption">
            <span class="kz-hv-title">${escapeHtml(cfg.title)}</span>
          </div>
        </div>`;
    } else if (cfg.provider === 'illustration' || (!cfg.id && !cfg.mp4Url)){
      // Default: full-screen Jewish illustration as the hero (no video at all).
      const ilKey = cfg.illustration || 'jerusalem';
      const bgUrl = (window.KZ_ILLUSTRATIONS && window.KZ_ILLUSTRATIONS[ilKey])
        ? window.KZ_ILLUSTRATIONS[ilKey]({ w: 1600, h: 800 })
        : '';
      wrap.classList.add('kz-hv-illustration');
      wrap.innerHTML = `
        <div class="kz-hv-shell" style="${bgUrl ? `background:url('${bgUrl}') center/cover no-repeat,#0B1F3A;` : 'background:linear-gradient(180deg,#0B1F3A,#14315b);'}">
          <div class="kz-hv-vignette" aria-hidden="true"></div>
          <div class="kz-hv-caption">
            <span class="kz-hv-pill">✦</span>
            <span class="kz-hv-title">${escapeHtml(cfg.title)}</span>
          </div>
        </div>`;
    } else {
      wrap.classList.add('kz-hv-empty');
      wrap.innerHTML = `<div class="kz-hv-shell"><div class="kz-hv-caption">
        <span class="kz-hv-title">${escapeHtml(cfg.title)}</span>
      </div></div>`;
    }

    document.body.insertBefore(wrap, document.body.firstChild);
  }

  function escapeHtml(s){
    return String(s ?? '').replace(/[&<>"']/g, m => ({
      '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'
    }[m]));
  }
  function escapeAttr(s){ return escapeHtml(s); }

  if (document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', buildBanner, { once: true });
  } else {
    buildBanner();
  }

  window.KZ_HERO_VIDEO_API = {
    rebuild(){
      const old = document.querySelector('.kz-hero-video');
      if (old) old.remove();
      buildBanner();
    }
  };
})();
