# 🌟 גרסה v1.8 — 38 בתי חב"ד מאומתים מ-Chabad.org

## 💛 הסיפור
איציק שלח לי קובץ בעבודת ידיים — **38 בתי חב"ד מאומתים** מהמקור הרשמי (chabad.org), עם:
- 📞 טלפונים אמיתיים
- 📍 כתובות מלאות
- 🌐 אתרים אמיתיים
- 🔗 קישור למקור chabad.org לכל אחד
- 📅 תאריך אימות (2026-05-04)
- 🏷 status (ready / draft) ורמת אימות (full / partial / pending)

החלטתי בלי היסוס: **זה זהב — נכניס מיד.**

---

## 📊 הפילוח של הקובץ החדש

| מדינה | רשומות | ready | draft |
|--------|--------|--------|-------|
| 🇮🇱 ישראל (ירושלים) | 8 | 7 | 1 |
| 🇺🇸 ארה"ב (Brooklyn 770) | 8 | 6 | 2 |
| 🇬🇧 אנגליה (לונדון) | 9 | 7 | 2 |
| 🇫🇷 צרפת (פריז) | 6 | 5 | 1 |
| 🇹🇭 תאילנד (בנגקוק) | 3 | 2 | 1 |
| 🇦🇪 איחוד הנסיכויות | 2 | 2 | 0 |
| 🇲🇽 מקסיקו (קנקון) | 1 | 0 | 1 |
| 🇹🇼 טאיוואן (טאיפיי) — **חדש!** | 1 | 0 | 1 |
| **סה"כ** | **38** | **31** | **7** |

---

## ✨ שינויים ב-UI

### 1. Badge מאומת ✓
כל מקום שמאומת מקבל בדג'יר ירוק יפה ליד השם:
```
Chabad Lubavitch UK Headquarters [✓ מאומת]
```
טיוטות מקבלות בדג' זהוב:
```
Beit Loubavitch Centre Siège [טיוטה]
```

### 2. שורת פעולות חדשה
לכל מקום מאומת:
- 🚗 **Waze** (כפתור ראשי)
- 🗺 **Google Maps**
- 📞 **טלפון** (כפתור ירוק בולט עם המספר המלא — `tel:` directly callable)
- 🌐 **אתר** (כפתור עם הדומיין הרשמי)
- 🔗 **Chabad.org** (קישור למקור — לראות פרטים מלאים)
- ↗ **שתף**

### 3. Place Type
מציג את הסוג המדויק: "Israeli Center", "Campus Chabad House", "Jewish Community Center", "Day School" וכו'.

### 4. ✓ "רק מאומת" — Toggle חדש
בשורת הסינון: checkbox ירוק יפה לסנן רק את 31 הרשומות המאומתות (לפעמים זה כל מה שאתה רוצה לראות).

### 5. Popup על המפה
הוספתי ✓ ירוק קטן ליד השם של מקומות מאומתים, וגם הכתובת המלאה.

---

## 🗄 שדות החדשים (מאוחסנים בכל place)

```js
{
  id: 'chb-00001',
  status: 'ready',          // 'ready' | 'draft'
  verified: 'full',          // 'full' | 'partial' | 'pending'
  cat: 'chabad',
  cc: 'TH',
  continent: 'asia',
  country: 'תאילנד',
  city: 'Bangkok',
  name: 'Chabad of Bangkok — Ohr Menachem',
  place_type: 'Israeli Center / Chabad House',
  addr: '18 Phra Athit Rd, ...',
  phone: '+66-2-629-2770',
  website: 'https://www.JewishThailand.com',
  source_url: 'https://www.chabad.org/jewish-centers/118405/...',
  verified_at: '2026-05-04',
  notes: 'כתובת, אתר וטלפון הופיעו במקור',
  lat: 13.7592, lng: 100.4944,
  fame: 9, comm: 'חב"ד'
}
```

---

## 📁 קבצים שהשתנו

```
+ data/chabad-verified.js          (38 רשומות מאומתות)
~ world.html                        (טוען את הקובץ + verified-only checkbox)
~ kz-world.css                      (badges ירוק/זהב + verified toggle styling)
~ kz-world-browser.js               (בדגי'ם, סינון מאומת, פוטון, אתר ככפתור)
~ data/world-index.js               (+ 🇹🇼 טאיוואן)
~ sw.js                             (VERSION → v1.8.0)
```

---

## 🎯 איך מוסיפים עוד רשומות?

הסקריפט הוא רגיל — פותחים את `data/chabad-verified.js`, מוסיפים אובייקט חדש לפי אותה תבנית. זה מתמזג אוטומטית למאגר הראשי דרך ה-IIFE שבסוף הקובץ.

**אם תשלח לי עוד 100 או 1000 רשומות — אני אעבד הכל באותו פורמט.**

---

## 🚀 v1.9 הצעות

1. **הזרמה מתמשכת** — הוספת עוד 200-500 בתי חב"ד מאומתים
2. **Marker clustering** ביבשות צפופות (Leaflet.markercluster)
3. **Photos מ-Wikipedia/Chabad.org** לבתי חב"ד מובילים
4. **שעות פתיחה / זמני תפילה** לכל בית חב"ד
5. **דירוג / ביקורות** משתמשים
6. **הוסף מקום** — submission flow מתורם
7. **מסלול PDF להדפסה** — שבת בעיר X (חב"ד הקרוב + מקווה + מסעדה)
