# 🎯 גרסה v1.4 — מרכז התפילה / my-hom.net

## ✨ מה התווסף

### 1. 🎥 Hero Video — קליטת כל URL של YouTube
- במקום להזין `id` ידנית, אפשר לשים URL מלא:
  ```html
  <script>window.KZ_HERO_VIDEO_URL = 'https://www.youtube.com/watch?v=XYZ';</script>
  ```
- תומך בכל פורמט: `youtube.com/watch?v=`, `youtu.be/`, `/embed/`, `/shorts/`, או id גלמי.
- ברירת המחדל היא placeholder — **חפש ב-YouTube "Jerusalem 360 4K" / "Western Wall VR"** והדבק URL.

### 2. 🔐 Sign-in מודרני
- מודל ייעודי `kz-auth-pro.js` עם 4 דרכי כניסה:
  - 🍎 **Apple Sign-In** (Supabase OAuth)
  - 🌐 **Google Sign-In** (Supabase OAuth)
  - ✉️ **Magic-link** (passwordless)
  - 🔒 **PIN מקומי** (4 ספרות, אופליין מלא, ללא חשבון)
- שמירת פרופיל ב-localStorage + sync ל-Supabase auth.
- אירוע גלובלי: `document.addEventListener('kz:profile', e => …)` לעדכן את ה-UI.
- `KZ_AUTH.profile()` / `KZ_AUTH.signOut()`.
- כל אלמנט עם `class="js-kz-signin"` יפתח את המודל.

### 3. 🎤 Cantor Mode — מסך חזן (`/cantor.html`)
- 8 תפילות מובנות: שמע, עמידה, קדיש, הבדלה, התקווה, ברכת כהנים, תהלים כג, תהלים קכא.
- טקסט גדול (28-120px), Auto-scroll עם מהירות מתכווננת, מסך מלא, ניגוד גבוה.
- **Wake Lock**: המסך לא נכבה תוך כדי תפילה.
- קיצורי מקלדת: Space / ↑↓ / +- / F / H.

### 4. 🌍 Heatmap Trails
- ה-canvas heatmap מוסיף **קווי אור מעוקלים** בין ערים — עם pulse שעובר ועיגון אחד תמיד בישראל.
- אפקט קולנועי חזק שעובד ב-60fps גם בנייד.

### 5. 🖼 OG Image דינמי
- `/api/og-image?title=…&subtitle=…&category=רפואה`
- מחזיר SVG מלא (1200×630) עם רקע, מגן דוד, pill קטגוריה, וכפתור "הצטרף לתפילה".
- שני נושאים: `gold` ו-`night`.
- `kz-share.js`: כל אלמנט `class="js-kz-share" data-title="…" data-category="רפואה"` משתף עם תמונה ייחודית.
- Web Share API עם fallback אוטומטי לוואטסאפ.

### 6. 📲 PWA Shortcuts + Share Target
- Manifest עודכן — נוספו קיצורים: **מצב חזן**, **מפת היהדות**, **תרומה**.
- `share_target` — אפשר עכשיו לשתף לאתר מאפליקציות אחרות (Android).

---

## 🔧 הגדרות חדשות ב-`index.html`

```html
<!-- Supabase (לAuth) -->
<script>
  window.KZ_SUPABASE_URL  = 'https://YOUR.supabase.co';
  window.KZ_SUPABASE_ANON = 'eyJ…';
</script>

<!-- Hero video — paste any YouTube URL -->
<script>
  window.KZ_HERO_VIDEO_URL = 'https://www.youtube.com/watch?v=YOUR_ID';
</script>
```

לאקטיבציה של Apple Sign-In ב-Supabase:
1. Supabase → Authentication → Providers → Apple → Enable.
2. Apple Developer → Sign in with Apple → צור Service ID + Key.
3. הדבק ב-Supabase.

---

## 📁 קבצים חדשים

```
+ kz-auth-pro.js / .css            (Sign-in מודרני)
+ cantor.html / .css / .js         (Cantor Mode)
+ kz-share.js                      (Share with dynamic OG)
+ netlify/functions/og-image.js    (SVG generator)
~ kz-hero-video.js                 (URL extraction)
~ kz-heatmap-globe.js              (Trails)
~ manifest.webmanifest             (Shortcuts + share target)
~ index.html                       (Refs + Supabase config)
~ netlify.toml                     (1 new redirect)
~ sw.js                            (VERSION → v1.4.0)
```

---

## 🚀 הצעות לסבב v1.5

| # | תכונה | למה |
|---|--------|------|
| 1 | **Pray-along** — תפילה משותפת בזמן אמת (WebRTC audio) | קהילה אמיתית |
| 2 | **AI prayer composer** — מירב מציעה ניסוח לתפילה אישית | ייחודי |
| 3 | **Spotify integration** — ניגונים ופיוטים מוכנים | אווירה |
| 4 | **Lazy-load images** + WebP/AVIF auto | ביצועים |
| 5 | **i18n של ה-OG image** לפי שפת המשתמש | ויראלי בינלאומי |
| 6 | **Dark/Light theme toggle** | נגישות |
| 7 | **Calendar widget** מלא (פרשה + זמני שבת) | עוגן יומי |
| 8 | **Yad2/Marketplace למצוות** (תרומת חפצים) | חסד |
| 9 | **Lighthouse 95+ pass** | אמינות |
| 10 | **Contributors map** — תורמים שכבר נתנו | חברתי |

תגיד "ממשיכים v1.5" עם מה שדחוף.
