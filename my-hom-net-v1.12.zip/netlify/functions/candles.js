/* ============================================================
   Netlify Function: /api/candles
   Live virtual Shabbat-candle wall.

   GET  ?live=1   → returns up to 200 candles whose havdalaAt is in
                    the future (i.e., still burning) ordered DESC.
   POST { name, prayer, city, cityId?, candleAt, havdalaAt }
        → inserts a new candle; auto-extinguishes after havdala via
          a TTL filter on read (so no cron required for cleanup).

   SQL (Supabase):
     create table shabbat_candles_live (
       id uuid primary key default gen_random_uuid(),
       name text not null,
       prayer text,
       city text,
       city_id text,
       candle_at timestamptz,
       havdala_at timestamptz,
       created_at timestamptz default now()
     );
     create index on shabbat_candles_live (havdala_at);
   ============================================================ */
const HEADERS = {
  'Content-Type': 'application/json',
  'Cache-Control': 'no-store',
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type'
};

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return { statusCode: 204, headers: HEADERS, body: '' };
  const sUrl = process.env.SUPABASE_URL;
  const sKey = process.env.SUPABASE_SERVICE_KEY;
  if (!sUrl || !sKey){
    // Without DB, fall back to an empty wall — clients keep their own local candles
    if (event.httpMethod === 'GET'){
      return { statusCode: 200, headers: HEADERS, body: JSON.stringify({ candles: [] }) };
    }
    return { statusCode: 200, headers: HEADERS, body: JSON.stringify({ ok: true, persisted: false }) };
  }

  if (event.httpMethod === 'GET'){
    // Only candles whose havdala is in the future are still "burning"
    const nowIso = new Date().toISOString();
    const url = `${sUrl}/rest/v1/shabbat_candles_live?havdala_at=gte.${encodeURIComponent(nowIso)}&select=id,name,prayer,city,candle_at,havdala_at,created_at&order=created_at.desc&limit=200`;
    const r = await fetch(url, {
      headers: { 'apikey': sKey, 'Authorization': `Bearer ${sKey}` }
    });
    if (!r.ok){
      return { statusCode: 502, headers: HEADERS, body: JSON.stringify({ error: 'DB read', candles: [] }) };
    }
    const rows = await r.json();
    const candles = rows.map(c => ({
      id: c.id,
      name: c.name,
      prayer: c.prayer,
      city: c.city,
      candleAt: c.candle_at,
      havdalaAt: c.havdala_at,
      created_at: c.created_at
    }));
    return { statusCode: 200, headers: HEADERS, body: JSON.stringify({ candles }) };
  }

  if (event.httpMethod !== 'POST') return { statusCode: 405, headers: HEADERS, body: JSON.stringify({ error: 'Method not allowed' }) };

  let body;
  try { body = JSON.parse(event.body || '{}'); }
  catch { return { statusCode: 400, headers: HEADERS, body: JSON.stringify({ error: 'Invalid JSON' }) }; }

  const name      = String(body.name    || '').slice(0, 80).trim();
  const prayer    = String(body.prayer  || '').slice(0, 500).trim();
  const city      = String(body.city    || '').slice(0, 100).trim();
  const cityId    = String(body.cityId  || '').slice(0, 40);
  const candleAt  = body.candleAt  ? new Date(body.candleAt).toISOString()  : null;
  const havdalaAt = body.havdalaAt ? new Date(body.havdalaAt).toISOString() : null;

  if (!name){
    return { statusCode: 400, headers: HEADERS, body: JSON.stringify({ error: 'Missing name' }) };
  }
  if (!havdalaAt){
    // Default: candle "burns" 30 hours if havdala unknown
    const fallback = new Date(Date.now() + 30 * 3600_000).toISOString();
    body._havdala_fallback = fallback;
  }

  const r = await fetch(`${sUrl}/rest/v1/shabbat_candles_live`, {
    method: 'POST',
    headers: {
      'apikey': sKey, 'Authorization': `Bearer ${sKey}`,
      'Content-Type': 'application/json',
      'Prefer': 'return=minimal'
    },
    body: JSON.stringify({
      name, prayer, city, city_id: cityId,
      candle_at: candleAt,
      havdala_at: havdalaAt || body._havdala_fallback
    })
  });
  if (!r.ok){
    const detail = await r.text();
    return { statusCode: 502, headers: HEADERS, body: JSON.stringify({ error: 'Insert failed', detail: detail.slice(0, 200) }) };
  }
  return { statusCode: 200, headers: HEADERS, body: JSON.stringify({ ok: true }) };
};
