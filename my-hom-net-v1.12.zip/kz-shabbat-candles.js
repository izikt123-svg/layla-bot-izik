/* ============================================================
   KZ SHABBAT CANDLES — virtual candle lighting + global wall
   - Hebcal Shabbat API for candle/havdala times per city
   - Live wall syncs every 20s
   - Auto-extinguish after havdala (server-side via TTL)
   ============================================================ */
(function(){
  'use strict';

  const $ = (s) => document.querySelector(s);

  /* ─── Hebcal time fetch per city (geonameid) ─── */
  async function fetchShabbatByGeonameId(id){
    const r = await fetch(`https://www.hebcal.com/shabbat?cfg=json&geonameid=${id}&m=18`);
    if (!r.ok) throw new Error('hebcal');
    return r.json();
  }
  async function fetchShabbatByLatLng(lat, lng){
    const r = await fetch(`https://www.hebcal.com/shabbat?cfg=json&latitude=${lat}&longitude=${lng}&m=18`);
    if (!r.ok) throw new Error('hebcal');
    return r.json();
  }

  function fmtTime(iso){
    if (!iso) return '—';
    const d = new Date(iso);
    return d.toLocaleTimeString('he-IL', { hour: '2-digit', minute: '2-digit' });
  }
  function fmtDate(iso){
    if (!iso) return '';
    const d = new Date(iso);
    return d.toLocaleDateString('he-IL', { weekday: 'long', day: 'numeric', month: 'long' });
  }

  /* ─── State ─── */
  const state = {
    cityId: '281184',         // default Jerusalem
    cityName: 'ירושלים',
    candle: null,             // ISO
    havdala: null,            // ISO
    parsha: null,
    geo: null
  };

  /* ─── Render times card ─── */
  async function refreshTimes(){
    const timesEl = $('#scTimes');
    const tzEl = $('#scTz');
    timesEl.innerHTML = `
      <div class="sc-time-row sc-time-skel"><span>הדלקת נרות</span><span>טוען…</span></div>
      <div class="sc-time-row sc-time-skel"><span>צאת השבת</span><span>טוען…</span></div>
      <div class="sc-time-row sc-time-skel"><span>פרשת השבוע</span><span>טוען…</span></div>`;

    let data;
    try {
      data = state.geo
        ? await fetchShabbatByLatLng(state.geo.lat, state.geo.lng)
        : await fetchShabbatByGeonameId(state.cityId);
    } catch {
      timesEl.innerHTML = '<div class="sc-time-row"><span>לא הצלחנו לטעון את הזמנים</span><span>—</span></div>';
      return;
    }

    state.cityName = data.location?.title || state.cityName;
    if (tzEl) tzEl.textContent = (data.location?.tzid || '').replace(/_/g, ' ');

    const now = Date.now();
    const candleIt  = (data.items || []).find(i => i.category === 'candles'  && new Date(i.date).getTime() > now - 12 * 3600_000);
    const havdalaIt = (data.items || []).find(i => i.category === 'havdalah' && new Date(i.date).getTime() > now - 1  * 3600_000);
    const parshaIt  = (data.items || []).find(i => i.category === 'parashat');

    state.candle  = candleIt?.date || null;
    state.havdala = havdalaIt?.date || null;
    state.parsha  = parshaIt?.hebrew || parshaIt?.title || '—';

    timesEl.innerHTML = `
      <div class="sc-time-row sc-candle">
        <span>🕯 הדלקת נרות (${fmtDate(state.candle)})</span>
        <span>${fmtTime(state.candle)}</span>
      </div>
      <div class="sc-time-row sc-havdala">
        <span>✨ צאת השבת</span>
        <span>${fmtTime(state.havdala)}</span>
      </div>
      <div class="sc-time-row">
        <span>📜 פרשת השבוע</span>
        <span>${escapeHtml(state.parsha)}</span>
      </div>`;

    const untilEl = $('#scUntil');
    if (untilEl) untilEl.textContent = state.havdala ? `צאת השבת (${fmtTime(state.havdala)})` : 'צאת השבת';

    refreshCountdown();
    setInterval(refreshCountdown, 30_000);
  }

  function refreshCountdown(){
    const c = $('#scCountdown');
    if (!c) return;
    if (!state.candle){ c.hidden = true; return; }
    const now = Date.now();
    const candle  = new Date(state.candle).getTime();
    const havdala = state.havdala ? new Date(state.havdala).getTime() : 0;
    if (now < candle){
      const diff = candle - now;
      c.hidden = false;
      c.innerHTML = `⏳ הדלקת נרות בעוד <b>${formatDelta(diff)}</b>`;
    } else if (havdala && now < havdala){
      const diff = havdala - now;
      c.hidden = false;
      c.innerHTML = `🕯 השבת נכנסה. צאת השבת בעוד <b>${formatDelta(diff)}</b>`;
    } else {
      c.hidden = false;
      c.innerHTML = `שבת שלום ✦ הזמן הבא יוצג ביום שישי הקרוב`;
    }
  }

  function formatDelta(ms){
    const totalMin = Math.floor(ms / 60000);
    const days = Math.floor(totalMin / 1440);
    const hr   = Math.floor((totalMin % 1440) / 60);
    const min  = totalMin % 60;
    if (days > 0) return `${days} ימים, ${hr} שעות`;
    if (hr  > 0) return `${hr} שעות ו-${min} דקות`;
    return `${min} דקות`;
  }

  /* ─── Light a candle ─── */
  async function light(payload){
    try {
      const r = await fetch('/api/candles', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      if (!r.ok) throw new Error();
      return await r.json();
    } catch {
      // Fallback: add locally so user sees their candle
      const local = JSON.parse(localStorage.getItem('kz_local_candles_v1') || '[]');
      local.unshift({ ...payload, id: 'local_' + Date.now(), local: true });
      localStorage.setItem('kz_local_candles_v1', JSON.stringify(local.slice(0, 50)));
      return { ok: true, local: true };
    }
  }

  function wireForm(){
    const form = $('#scForm');
    const success = $('#scSuccess');
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const name = $('#scName').value.trim();
      const prayer = $('#scPrayer').value.trim();
      const anon = $('#scAnon').checked;
      if (!name){ $('#scName').focus(); return; }

      $('#scLightBtn').disabled = true;
      const payload = {
        name: anon ? 'אנונימית' : name,
        prayer,
        city: state.cityName,
        cityId: state.cityId,
        candleAt: state.candle,
        havdalaAt: state.havdala
      };
      await light(payload);
      form.hidden = true;
      success.hidden = false;
      refreshWall();
    });

    $('#scLightAgain').addEventListener('click', () => {
      $('#scForm').reset();
      $('#scForm').hidden = false;
      $('#scSuccess').hidden = true;
      $('#scLightBtn').disabled = false;
    });
  }

  /* ─── Wall fetch + render ─── */
  async function fetchWall(){
    try {
      const r = await fetch('/api/candles?live=1', { cache: 'no-store' });
      if (!r.ok) throw new Error();
      return await r.json();
    } catch {
      // Fallback: local storage
      const local = JSON.parse(localStorage.getItem('kz_local_candles_v1') || '[]');
      return { candles: local };
    }
  }

  function svgCandle(){
    return `<svg class="sc-svg-candle" viewBox="0 0 56 96" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <defs>
        <linearGradient id="cWax" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="#fff7e0"/>
          <stop offset="100%" stop-color="#d4b07a"/>
        </linearGradient>
        <radialGradient id="cFlame" cx="50%" cy="60%" r="60%">
          <stop offset="0%" stop-color="#fff7c0"/>
          <stop offset="55%" stop-color="#ffb648"/>
          <stop offset="100%" stop-color="#ff5b1f" stop-opacity="0"/>
        </radialGradient>
      </defs>
      <!-- glow -->
      <circle cx="28" cy="32" r="22" fill="url(#cFlame)" opacity=".55"/>
      <!-- wax -->
      <rect x="20" y="46" width="16" height="44" rx="3" fill="url(#cWax)" stroke="#9c7a40" stroke-width="0.6"/>
      <!-- wick -->
      <rect x="27" y="40" width="2" height="6" fill="#5a3c14"/>
      <!-- flame -->
      <g class="sc-svg-flame">
        <ellipse cx="28" cy="34" rx="6.5" ry="11" fill="url(#cFlame)"/>
        <ellipse cx="28" cy="36" rx="3.5" ry="6" fill="#ffe28a"/>
        <ellipse cx="28" cy="38" rx="1.5" ry="3" fill="#fffce8"/>
      </g>
    </svg>`;
  }

  function escapeHtml(s){
    return String(s ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  }

  function renderWall(list){
    const wall = $('#scWall');
    const count = $('#scWallCount');
    if (!wall) return;
    const arr = (list || []).slice(0, 60);
    count.textContent = arr.length;
    wall.innerHTML = arr.map(c => `
      <div class="sc-candle-card">
        <span class="sc-candle-time">${fmtTime(c.candleAt || c.created_at) || ''}</span>
        ${svgCandle()}
        <div class="sc-candle-name">${escapeHtml(c.name || 'אנונימית')}</div>
        <div class="sc-candle-city">${escapeHtml(c.city || '')}</div>
        ${c.prayer ? `<div class="sc-candle-prayer">${escapeHtml(c.prayer)}</div>` : ''}
      </div>`).join('');
  }

  async function refreshWall(){
    const data = await fetchWall();
    renderWall(data.candles || []);
  }

  /* ─── Init ─── */
  async function init(){
    const sel = $('#scCity');
    sel.addEventListener('change', () => {
      state.cityId = sel.value;
      state.cityName = sel.options[sel.selectedIndex].textContent;
      state.geo = null;
      refreshTimes();
    });

    $('#scLocate').addEventListener('click', () => {
      if (!navigator.geolocation){ alert('הדפדפן לא תומך במיקום'); return; }
      $('#scLocate').textContent = '⏳';
      navigator.geolocation.getCurrentPosition((g) => {
        state.geo = { lat: g.coords.latitude, lng: g.coords.longitude };
        $('#scLocate').textContent = '✓';
        refreshTimes();
      }, () => {
        $('#scLocate').textContent = '🛰';
        alert('לא הצלחנו לזהות מיקום');
      }, { enableHighAccuracy: true, timeout: 10000 });
    });

    wireForm();
    refreshTimes();
    refreshWall();
    setInterval(refreshWall, 20_000);
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, { once: true });
  else init();
})();
